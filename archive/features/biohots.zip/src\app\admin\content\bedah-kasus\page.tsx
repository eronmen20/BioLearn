'use client';

import { useState, useEffect, useCallback } from 'react';
import { AdminPageHeader } from '@/components/admin/page-header';
import { showToast } from '@/components/ui/toaster';
import { Modal, ConfirmDialog } from '@/components/admin/modal';
import { BAB } from '@/lib/bab-data';
import {
  Compass, Plus, Trash2, Save, Loader2, Edit3, Eye, CheckCircle2,
  AlertCircle, Sparkles, HelpCircle, Layers, ArrowRight, RefreshCw,
} from 'lucide-react';
import { adminFetch } from "@/lib/admin-fetch";
import type { BedahKasusItem, ReasoningQuestion } from '@/lib/bedah-kasus-data';

const inputCls = "w-full px-3 py-2 border border-border rounded-xl bg-bg-alt text-ink text-sm focus:outline-none focus:ring-2 focus:ring-accent/30";

const DEFAULT_QUESTION: ReasoningQuestion = {
  id: "q1",
  question_id: "",
  question_en: "",
  options_id: ["", "", "", "", ""],
  options_en: ["", "", "", "", ""],
  correct_answer: 0,
  explanation_id: "",
  explanation_en: "",
  reasoning_steps_id: [""],
  reasoning_steps_en: [""],
  distractor_analysis_id: "",
  distractor_analysis_en: "",
  utbk_tip_id: "",
  utbk_tip_en: "",
};

const EMPTY_CASE: BedahKasusItem = {
  id: "",
  slug: "",
  bab_id: "bakteri",
  title_id: "",
  title_en: "",
  target_exam: "UTBK-SNBT",
  difficulty: "sedang",
  summary_id: "",
  summary_en: "",
  scenario_id: "",
  scenario_en: "",
  experiment_setup_id: "",
  experiment_setup_en: "",
  image_url: "",
  image_caption_id: "",
  image_caption_en: "",
  data_headers: ["Parameter", "Hasil Uji", "Keterangan"],
  data_rows: [
    ["Sampel A", "Normal", "Kontrol"],
    ["Sampel B", "Mengalami Lisis", "Perlakuan"],
  ],
  variables: {
    independent: "",
    dependent: "",
    control: "",
  },
  questions: [DEFAULT_QUESTION],
  published: true,
  sort_order: 1,
};

export default function BedahKasusAdminPage() {
  const [cases, setCases] = useState<BedahKasusItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showEditor, setShowEditor] = useState(false);
  const [editing, setEditing] = useState<BedahKasusItem | null>(null);
  const [form, setForm] = useState<BedahKasusItem>(EMPTY_CASE);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState<BedahKasusItem | null>(null);
  const [showDelete, setShowDelete] = useState(false);
  const [activeTab, setActiveTab] = useState<"info" | "scenario" | "table" | "questions">("info");

  const refreshCases = useCallback(async () => {
    try {
      setLoading(true);
      const res = await adminFetch('/api/admin/bedah-kasus');
      const data = await res.json();
      setCases(data.cases || []);
    } catch {
      showToast('Gagal memuat data BioHOTS');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshCases();
  }, [refreshCases]);

  const openAdd = () => {
    setEditing(null);
    setForm({
      ...EMPTY_CASE,
      id: `kasus-${Date.now()}`,
      slug: `kasus-${Date.now()}`,
    });
    setActiveTab("info");
    setShowEditor(true);
  };

  const openEdit = (c: BedahKasusItem) => {
    setEditing(c);
    setForm(JSON.parse(JSON.stringify(c)));
    setActiveTab("info");
    setShowEditor(true);
  };

  const handleSave = async () => {
    if (!form.title_id.trim()) {
      showToast('Judul kasus wajib diisi');
      return;
    }
    try {
      setSaving(true);
      const res = await adminFetch('/api/admin/bedah-kasus', {
        method: editing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Gagal menyimpan');
      }
      showToast(editing ? 'Studi kasus berhasil diperbarui!' : 'Studi kasus baru berhasil ditambahkan!');
      setShowEditor(false);
      refreshCases();
    } catch (e) {
      showToast(`Gagal: ${e instanceof Error ? e.message : 'Unknown error'}`);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleting?.id) return;
    try {
      await adminFetch(`/api/admin/bedah-kasus?id=${deleting.id}`, { method: 'DELETE' });
      showToast('Kasus berhasil dihapus');
      refreshCases();
    } catch {
      showToast('Gagal menghapus kasus');
    } finally {
      setShowDelete(false);
      setDeleting(null);
    }
  };

  const handleResetDefaults = async () => {
    if (!confirm("Yakin ingin mereset ke studi kasus default bawaan? Data custom akan ditimpa.")) return;
    try {
      setLoading(true);
      const res = await adminFetch('/api/admin/bedah-kasus', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reset_defaults' }),
      });
      if (res.ok) {
        showToast('Berhasil mereset ke studi kasus default');
        refreshCases();
      }
    } catch {
      showToast('Gagal mereset');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <AdminPageHeader
        title="BioHOTS (Bedah Soal UTBK/TKA)"
        description="Kelola bank soal BioHOTS berbasis data eksperimen, stimulus penalaran, dan analisis jebakan"
        action={{ label: 'Tambah Soal BioHOTS', onClick: openAdd, icon: <Plus className="w-4 h-4" /> }}
      />

      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-xs text-muted">
          Total: <strong className="text-ink">{cases.length} soal BioHOTS</strong>
        </p>
        <button
          type="button"
          onClick={handleResetDefaults}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs font-semibold text-muted hover:text-ink hover:bg-bg-alt transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Reset ke Kasus Default
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20 text-sm text-muted">
          <Loader2 className="w-5 h-5 animate-spin mr-2" />
          Memuat data studi kasus...
        </div>
      ) : cases.length === 0 ? (
        <div className="bg-surface rounded-2xl border border-border p-10 text-center">
          <Compass className="w-10 h-10 text-muted mx-auto mb-3" />
          <p className="text-sm text-muted">Belum ada studi kasus. Klik “Tambah Studi Kasus” untuk membuat yang pertama.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {cases.map((c) => (
            <div key={c.id} className="bg-surface rounded-2xl border border-border/80 p-5 shadow-xs hover:border-accent/40 transition-colors flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                    c.published ? 'bg-green/10 text-green' : 'bg-border text-muted'
                  }`}>
                    {c.published ? 'Published' : 'Draft'}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-accent/10 text-accent">
                    {c.target_exam}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-bg-alt text-muted border border-border">
                    {c.bab_id}
                  </span>
                  <span className="text-[10px] font-semibold text-muted ml-auto">
                    {c.difficulty}
                  </span>
                </div>

                <h3 className="font-extrabold text-base text-ink mb-1.5 leading-snug">
                  {c.title_id}
                </h3>
                <p className="text-xs text-muted line-clamp-2 leading-relaxed mb-3">
                  {c.summary_id || c.scenario_id}
                </p>

                <div className="flex items-center gap-2 text-xs text-muted-2 mb-4">
                  <span>🧩 {c.questions?.length || 0} Pertanyaan Penalaran</span>
                  {c.data_rows && c.data_rows.length > 0 && <span>• 📊 Data Tabel ({c.data_rows.length} baris)</span>}
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-border/60">
                <a
                  href={`/bedah-kasus/${c.slug}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-semibold text-accent hover:underline"
                >
                  <Eye className="w-3.5 h-3.5" />
                  Lihat Siswa
                </a>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openEdit(c)}
                    className="p-2 rounded-xl hover:bg-bg-alt text-muted hover:text-ink transition-colors"
                    title="Edit kasus"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => { setDeleting(c); setShowDelete(true); }}
                    className="p-2 rounded-xl hover:bg-red/10 text-muted hover:text-red transition-colors"
                    title="Hapus kasus"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Editor Modal */}
      <Modal
        open={showEditor}
        onClose={() => setShowEditor(false)}
        title={editing ? 'Edit Studi Kasus UTBK/TKA' : 'Tambah Studi Kasus UTBK/TKA'}
      >
        <div className="space-y-4 max-h-[75vh] overflow-y-auto pr-1">
          {/* Navigation Tabs */}
          <div className="flex gap-1 border-b border-border pb-2">
            {[
              { id: "info", label: "1. Info & Kategori" },
              { id: "scenario", label: "2. Skenario & Bukti" },
              { id: "table", label: "3. Tabel Data" },
              { id: "questions", label: "4. Soal Penalaran" },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                  activeTab === tab.id ? "bg-accent text-white" : "text-muted hover:bg-bg-alt"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* TAB 1: INFO */}
          {activeTab === "info" && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-ink mb-1">Bab Pelajaran *</label>
                  <select
                    value={form.bab_id}
                    onChange={(e) => setForm({ ...form, bab_id: e.target.value })}
                    className={inputCls}
                  >
                    {BAB.map((b) => (
                      <option key={b.id} value={b.id}>{b.id.toUpperCase()}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-ink mb-1">Target Ujian</label>
                  <select
                    value={form.target_exam}
                    onChange={(e) => setForm({ ...form, target_exam: e.target.value as BedahKasusItem["target_exam"] })}
                    className={inputCls}
                  >
                    <option value="UTBK-SNBT">UTBK-SNBT</option>
                    <option value="TKA Saintek">TKA Saintek</option>
                    <option value="Olimpiade">Olimpiade Sains</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-ink mb-1">Tingkat Kesulitan</label>
                  <select
                    value={form.difficulty}
                    onChange={(e) => setForm({ ...form, difficulty: e.target.value as BedahKasusItem["difficulty"] })}
                    className={inputCls}
                  >
                    <option value="sedang">Sedang (HOTS Menengah)</option>
                    <option value="sulit">Sulit (HOTS Tinggi)</option>
                    <option value="sangat_sulit">Sangat Sulit (Olimpiade/Analisis Kompleks)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-ink mb-1">Slug URL</label>
                  <input
                    type="text"
                    value={form.slug}
                    onChange={(e) => setForm({ ...form, slug: e.target.value })}
                    placeholder="mis. resistensi-superbug"
                    className={inputCls}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-ink mb-1">Judul Kasus (ID) *</label>
                <input
                  type="text"
                  value={form.title_id}
                  onChange={(e) => setForm({ ...form, title_id: e.target.value })}
                  placeholder="mis. Studi Kasus Superbug di Ruang ICU"
                  className={inputCls}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-ink mb-1">Judul Kasus (EN)</label>
                <input
                  type="text"
                  value={form.title_en}
                  onChange={(e) => setForm({ ...form, title_en: e.target.value })}
                  placeholder="Title in English"
                  className={inputCls}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-ink mb-1">Ringkasan Masalah (ID)</label>
                <textarea
                  rows={2}
                  value={form.summary_id}
                  onChange={(e) => setForm({ ...form, summary_id: e.target.value })}
                  placeholder="Ringkasan singkat 1-2 kalimat"
                  className={inputCls}
                />
              </div>

              <div className="flex items-center gap-4 pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-ink">
                  <input
                    type="checkbox"
                    checked={form.published}
                    onChange={(e) => setForm({ ...form, published: e.target.checked })}
                    className="rounded border-border text-accent focus:ring-accent"
                  />
                  Publikasikan kasus ini untuk siswa
                </label>
              </div>
            </div>
          )}

          {/* TAB 2: SCENARIO */}
          {activeTab === "scenario" && (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-ink mb-1">Narasi Latar Belakang / Skenario (ID) *</label>
                <textarea
                  rows={4}
                  value={form.scenario_id}
                  onChange={(e) => setForm({ ...form, scenario_id: e.target.value })}
                  placeholder="Ceritakan temuan fenomena, kasus pasien di RS, atau observasi alam..."
                  className={inputCls}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-ink mb-1">Prosedur / Metodologi Eksperimen (ID)</label>
                <textarea
                  rows={3}
                  value={form.experiment_setup_id}
                  onChange={(e) => setForm({ ...form, experiment_setup_id: e.target.value })}
                  placeholder="Bagaimana eksperimen dilakukan? Media apa yang dipakai? Parameter apa yang diukur?"
                  className={inputCls}
                />
              </div>

              <div className="p-3.5 bg-bg-alt rounded-xl border border-border/60 space-y-2">
                <p className="text-xs font-bold text-ink">Identifikasi Variabel Penelitian</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[11px] text-muted mb-0.5">Variabel Bebas</label>
                    <input
                      type="text"
                      value={form.variables?.independent || ""}
                      onChange={(e) => setForm({ ...form, variables: { ...form.variables!, independent: e.target.value } })}
                      placeholder="mis. Konsentrasi obat"
                      className={inputCls}
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-muted mb-0.5">Variabel Terikat</label>
                    <input
                      type="text"
                      value={form.variables?.dependent || ""}
                      onChange={(e) => setForm({ ...form, variables: { ...form.variables!, dependent: e.target.value } })}
                      placeholder="mis. Diameter zona hambat"
                      className={inputCls}
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-muted mb-0.5">Variabel Kontrol</label>
                    <input
                      type="text"
                      value={form.variables?.control || ""}
                      onChange={(e) => setForm({ ...form, variables: { ...form.variables!, control: e.target.value } })}
                      placeholder="mis. Suhu 37°C, media agar"
                      className={inputCls}
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-ink mb-1">URL Gambar / Grafik Pendukung (Opsional)</label>
                <input
                  type="text"
                  value={form.image_url || ""}
                  onChange={(e) => setForm({ ...form, image_url: e.target.value })}
                  placeholder="https://... atau /images/grafik-kasus.png"
                  className={inputCls}
                />
              </div>
            </div>
          )}

          {/* TAB 3: TABLE DATA */}
          {activeTab === "table" && (
            <div className="space-y-3">
              <p className="text-xs text-muted">
                Tabel data eksperimen akan ditampilkan kepada siswa untuk dianalisis polanya.
              </p>
              <div>
                <label className="block text-xs font-bold text-ink mb-1">Header Kolom (Pisahkan dengan Koma)</label>
                <input
                  type="text"
                  value={form.data_headers?.join(", ") || ""}
                  onChange={(e) => setForm({
                    ...form,
                    data_headers: e.target.value.split(",").map((s) => s.trim()).filter(Boolean),
                  })}
                  placeholder="mis. Kode, Jenis Antibiotik, Diameter Zona (mm)"
                  className={inputCls}
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-ink mb-1">Baris Data (1 Baris = 1 Baris Tabel, Pisahkan Kolom dengan Koma)</label>
                <textarea
                  rows={5}
                  value={form.data_rows?.map((r) => r.join(", ")).join("\n") || ""}
                  onChange={(e) => {
                    const rows = e.target.value
                      .split("\n")
                      .filter((line) => line.trim())
                      .map((line) => line.split(",").map((c) => c.trim()));
                    setForm({ ...form, data_rows: rows });
                  }}
                  placeholder="AMP, Ampisilin, 0 mm&#10;MEM, Meropenem, 11 mm"
                  className={inputCls}
                />
              </div>
            </div>
          )}

          {/* TAB 4: QUESTIONS */}
          {activeTab === "questions" && (
            <div className="space-y-4">
              {form.questions.map((q, qIdx) => (
                <div key={q.id || qIdx} className="p-4 rounded-xl border border-border bg-bg-alt/50 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-accent">Soal Penalaran #{qIdx + 1}</span>
                    <span className="text-[11px] text-muted">Format UTBK Pilihan Ganda</span>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-ink mb-1">Pertanyaan Analisis Data *</label>
                    <textarea
                      rows={2}
                      value={q.question_id}
                      onChange={(e) => {
                        const newQ = [...form.questions];
                        newQ[qIdx].question_id = e.target.value;
                        setForm({ ...form, questions: newQ });
                      }}
                      placeholder="Berdasarkan data tabel di atas, kesimpulan yang paling tepat adalah..."
                      className={inputCls}
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-ink">5 Opsi Jawaban (Pilih Lingkaran untuk Kunci Benar)</label>
                    {["A", "B", "C", "D", "E"].map((optLabel, optIdx) => (
                      <div key={optIdx} className="flex items-center gap-2">
                        <input
                          type="radio"
                          name={`correct_${qIdx}`}
                          checked={q.correct_answer === optIdx}
                          onChange={() => {
                            const newQ = [...form.questions];
                            newQ[qIdx].correct_answer = optIdx;
                            setForm({ ...form, questions: newQ });
                          }}
                          className="text-accent focus:ring-accent"
                        />
                        <span className="text-xs font-bold text-ink w-4">{optLabel}</span>
                        <input
                          type="text"
                          value={q.options_id[optIdx] || ""}
                          onChange={(e) => {
                            const newQ = [...form.questions];
                            newQ[qIdx].options_id[optIdx] = e.target.value;
                            setForm({ ...form, questions: newQ });
                          }}
                          placeholder={`Pilihan ${optLabel}`}
                          className={inputCls}
                        />
                      </div>
                    ))}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-ink mb-1">Pembahasan Logika Sains</label>
                    <textarea
                      rows={2}
                      value={q.explanation_id}
                      onChange={(e) => {
                        const newQ = [...form.questions];
                        newQ[qIdx].explanation_id = e.target.value;
                        setForm({ ...form, questions: newQ });
                      }}
                      placeholder="Kenapa jawaban tersebut benar secara konsep biologi..."
                      className={inputCls}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-ink mb-1">Langkah Penalaran Bertahap (1 baris per langkah)</label>
                    <textarea
                      rows={3}
                      value={q.reasoning_steps_id?.join("\n") || ""}
                      onChange={(e) => {
                        const newQ = [...form.questions];
                        newQ[qIdx].reasoning_steps_id = e.target.value.split("\n").filter(Boolean);
                        setForm({ ...form, questions: newQ });
                      }}
                      placeholder="Langkah 1: Baca tren data pada kolom diameter&#10;Langkah 2: Bandingkan dengan standar klinis..."
                      className={inputCls}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-ink mb-1">Trik Cepat Khas UTBK</label>
                    <input
                      type="text"
                      value={q.utbk_tip_id || ""}
                      onChange={(e) => {
                        const newQ = [...form.questions];
                        newQ[qIdx].utbk_tip_id = e.target.value;
                        setForm({ ...form, questions: newQ });
                      }}
                      placeholder="mis. Jangan terkecoh dengan angka mutlak, perhatikan kontrolnya!"
                      className={inputCls}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-border">
            <button
              type="button"
              onClick={() => setShowEditor(false)}
              className="px-4 py-2 rounded-xl border border-border text-xs font-semibold hover:bg-bg-alt text-muted"
            >
              Batal
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-accent text-white text-xs font-bold hover:bg-accent-dark transition-all disabled:opacity-50"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {saving ? "Menyimpan..." : "Simpan Kasus"}
            </button>
          </div>
        </div>
      </Modal>

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={showDelete}
        onClose={() => setShowDelete(false)}
        onConfirm={handleDelete}
        title="Hapus Studi Kasus?"
        message={`Yakin ingin menghapus studi kasus "${deleting?.title_id}"? Data yang dihapus tidak dapat dipulihkan.`}
        confirmLabel="Hapus Kasus"
      />
    </div>
  );
}
