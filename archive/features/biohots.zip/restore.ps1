# Script Pemulihan Otomatis BioHOTS
Write-Host "Memulihkan fitur BioHOTS..." -ForegroundColor Cyan

$root = "$PSScriptRoot\..\..\.."
$archiveSrc = "$PSScriptRoot\src"

# 1. Salin kembali semua file kode ke src
Copy-Item -Recurse -Force "$archiveSrc\*" "$root\src"

# 2. Terapkan patch integrasi UI
Set-Location -Path $root
git apply "$PSScriptRoot\ui_integrations.patch"

Write-Host "Fitur BioHOTS berhasil dipulihkan!" -ForegroundColor Green
Write-Host "Jalankan 'npm run dev' atau periksa http://localhost:3000/bedah-kasus" -ForegroundColor Yellow
