import { NextRequest, NextResponse } from "next/server";
import { getPublicDb } from "@/lib/db";
import { INITIAL_BEDAH_KASUS, type BedahKasusItem } from "@/lib/bedah-kasus-data";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const slug = searchParams.get("slug");
    const id = searchParams.get("id");
    const babId = searchParams.get("bab_id");

    let allCases: BedahKasusItem[] = INITIAL_BEDAH_KASUS;

    // Fetch custom / updated cases from Supabase site_settings
    try {
      const supabase = getPublicDb();
      const { data } = await supabase
        .from("site_settings")
        .select("value")
        .eq("key", "bedah_kasus")
        .single();

      if (data?.value && Array.isArray(data.value) && data.value.length > 0) {
        allCases = data.value;
      }
    } catch (dbErr) {
      // Fallback silently to in-memory initial cases
      console.warn("[API Bedah Kasus] Fallback to INITIAL_BEDAH_KASUS:", dbErr);
    }

    // Filter by slug or id if specified
    if (slug) {
      const found = allCases.find((c) => c.slug === slug && c.published !== false);
      if (!found) {
        return NextResponse.json({ error: "Kasus tidak ditemukan" }, { status: 404 });
      }
      return NextResponse.json({ item: found });
    }

    if (id) {
      const found = allCases.find((c) => c.id === id && c.published !== false);
      if (!found) {
        return NextResponse.json({ error: "Kasus tidak ditemukan" }, { status: 404 });
      }
      return NextResponse.json({ item: found });
    }

    // Filter published only
    let items = allCases.filter((c) => c.published !== false);

    if (babId && babId !== "all") {
      items = items.filter((c) => c.bab_id === babId);
    }

    items.sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));

    return NextResponse.json({ items });
  } catch (error) {
    console.error("[API Bedah Kasus GET Error]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
