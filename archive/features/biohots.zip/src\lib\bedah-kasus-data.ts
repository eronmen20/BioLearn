export interface ReasoningQuestion {
  id: string;
  question_id: string;
  question_en: string;
  options_id: string[];
  options_en: string[];
  correct_answer: number;
  explanation_id: string;
  explanation_en: string;
  reasoning_steps_id: string[];
  reasoning_steps_en: string[];
  distractor_analysis_id?: string;
  distractor_analysis_en?: string;
  utbk_tip_id: string;
  utbk_tip_en: string;
}

export interface BedahKasusItem {
  id: string;
  slug: string;
  bab_id: string;
  title_id: string;
  title_en: string;
  target_exam: "UTBK-SNBT" | "TKA Saintek" | "Olimpiade";
  difficulty: "sedang" | "sulit" | "sangat_sulit";
  summary_id: string;
  summary_en: string;
  scenario_id: string;
  scenario_en: string;
  experiment_setup_id: string;
  experiment_setup_en: string;
  image_url?: string;
  image_caption_id?: string;
  image_caption_en?: string;
  data_headers?: string[];
  data_rows?: string[][];
  variables?: {
    independent: string;
    dependent: string;
    control: string;
  };
  questions: ReasoningQuestion[];
  published: boolean;
  sort_order: number;
  created_at?: string;
}

export const INITIAL_BEDAH_KASUS: BedahKasusItem[] = [
  {
    id: "kasus-1-superbug",
    slug: "resistensi-superbug-klebsiella",
    bab_id: "bakteri",
    title_id: "Studi Kasus Superbug: Mengapa Antibiotik Lini Terakhir Bisa Gagal?",
    title_en: "Superbug Case Study: Why Do Last-Resort Antibiotics Fail?",
    target_exam: "UTBK-SNBT",
    difficulty: "sangat_sulit",
    summary_id: "Analisis data uji difusi cakram dan kurva pertumbuhan bakteri Klebsiella pneumoniae resisten karbapenem di ruang rawat intensif.",
    summary_en: "Analysis of disc diffusion and growth curve data for carbapenem-resistant Klebsiella pneumoniae in intensive care units.",
    scenario_id: "Seorang dokter di ruang ICU mengamati bahwa pasien pneumonia tidak kunjung sembuh setelah diberikan antibiotik ampisilin dan seftriakson selama 7 hari. Sampel sputum pasien dikultur di laboratorium mikrobiologi. Hasil identifikasi menunjukkan keberadaan koloni Klebsiella pneumoniae. Tim medis kemudian menguji efektivitas 4 jenis antibiotik dengan konsentrasi standar pada cawan agar Mueller-Hinton.",
    scenario_en: "An ICU physician noticed that pneumonia patients failed to recover after 7 days of ampicillin and ceftriaxone therapy. Sputum samples grew Klebsiella pneumoniae. The microbiology team tested 4 antibiotics at standard concentrations on Mueller-Hinton agar.",
    experiment_setup_id: "Empat cakram antibiotik diletakkan pada cawan petri berisi kultur bakteri murni dengan kepadatan 10^6 CFU/mL, diinkubasi pada 37°C selama 24 jam. Parameter yang diukur adalah diameter zona hambat (mm) dan keberadaan koloni satelit di dalam zona bening.",
    experiment_setup_en: "Four antibiotic discs were placed on petri dishes with pure cultures at 10^6 CFU/mL, incubated at 37°C for 24 hours. Inhibition zone diameters (mm) and satellite colonies within clear zones were recorded.",
    data_headers: ["Kode Cakram", "Jenis Antibiotik", "Mekanisme Kerja", "Diameter Zona (mm)", "Standar Sensitif Klinis", "Koloni Satelit"],
    data_rows: [
      ["AMP", "Ampisilin", "Menghambat sintesis dinding sel", "0 mm", "≥ 17 mm", "Tidak ada (Overgrown)"],
      ["CRO", "Seftriakson (Sefalosporin)", "Menghambat transpeptidase dinding sel", "6 mm", "≥ 21 mm", "Tidak ada"],
      ["MEM", "Meropenem (Karbapenem)", "Inhibitor dinding sel spektrum luas", "11 mm", "≥ 23 mm", "Ditemukan 4 koloni"],
      ["CST", "Kolistin (Polimiksin)", "Merusak membran plasma luar Gram (-)", "19 mm", "≥ 14 mm", "Tidak ada"],
    ],
    variables: {
      independent: "Jenis antibiotik dan mekanisme serangannya pada struktur bakteri",
      dependent: "Diameter zona hambat (mm) dan kelangsungan hidup koloni satelit",
      control: "Konsentrasi suspensi awal bakteri (10^6 CFU/mL), media agar, dan suhu inkubasi 37°C",
    },
    questions: [
      {
        id: "q1",
        question_id: "Berdasarkan data tabel hasil uji di atas, temuan koloni satelit pada zona hambat antibiotik Meropenem (MEM) paling logis mengindikasikan bahwa...",
        question_en: "Based on the table above, the appearance of satellite colonies within the Meropenem (MEM) inhibition zone most logically indicates that...",
        options_id: [
          "Meropenem telah menguraikan seluruh dinding peptidoglikan koloni bakteri secara tuntas",
          "Terdapat sebagian kecil sub-populasi bakteri yang telah memiliki mutasi genetik atau plasmid resistensi penghasil enzim karbapenemase",
          "Bakteri tersebut bersifat Gram positif sehingga tidak mempan terhadap inhibitor membran luar",
          "Konsentrasi agar pada cawan petri terlalu encer sehingga bakteri dapat berenang bebas",
          "Antibiotik Meropenem berubah menjadi sumber nutrisi makanan bagi bakteri patogen",
        ],
        options_en: [
          "Meropenem completely degraded the peptidoglycan cell walls of all bacterial colonies",
          "A small sub-population possesses genetic mutations or plasmids encoding carbapenemase resistance enzymes",
          "The bacteria are Gram-positive and therefore immune to outer membrane inhibitors",
          "The agar concentration was too low, allowing bacteria to swim across the dish",
          "Meropenem decomposed into a primary nutrient source for the pathogenic bacteria",
        ],
        correct_answer: 1,
        explanation_id: "Kemunculan koloni satelit di dalam zona bening adalah ciri khas adanya varian bakteri resisten (misalnya penghasil enzim KPC/Karbapenemase). Bakteri normal sensitif akan mati oleh antibiotik, namun segelintir sel yang bermutasi atau memiliki plasmid resisten sanggup bertahan dan berkembang biak di dekat cakram.",
        explanation_en: "Satellite colonies inside an inhibition zone signify resistant variants (e.g., carbapenemase producers). While sensitive bacteria die, mutants harboring resistance plasmids survive and divide.",
        reasoning_steps_id: [
          "Langkah 1: Perhatikan zona MEM sebesar 11 mm. Angka ini berada di bawah standar klinis (23 mm), menandakan status resisten.",
          "Langkah 2: Amati anomali koloni satelit di dalam lingkaran zona bening. Jika antibiotik membunuh semua bakteri, zona harusnya bersih total.",
          "Langkah 3: Keberadaan sel yang hidup di konsentrasi antibiotik tinggi membuktikan adanya variasi genetik resistensi dalam populasi bakteri tersebut.",
        ],
        reasoning_steps_en: [
          "Step 1: Check the MEM zone (11 mm), well below the sensitive threshold of 23 mm.",
          "Step 2: Note the satellite colonies inside the clear zone. A fully effective antibiotic leaves a clear ring.",
          "Step 3: Surviving cells in high antibiotic concentrations demonstrate pre-existing genetic resistance within the population.",
        ],
        distractor_analysis_id: "Opsi A salah karena jika terurai tuntas tidak akan ada koloni hidup. Opsi C salah karena Klebsiella adalah bakteri Gram negatif. Opsi D dan E tidak relevan secara sains biologis.",
        distractor_analysis_en: "Option A is false because complete breakdown leaves zero colonies. Option C is false because Klebsiella is Gram-negative. Options D and E are biologically invalid.",
        utbk_tip_id: "Di soal UTBK bertema mikrobiologi, kemunculan koloni di dekat cakram obat selalu merujuk pada seleksi alam dan resistensi plasmid, bukan kegagalan media percobaan.",
        utbk_tip_en: "In UTBK microbiology questions, colonies appearing inside inhibition rings always signify natural selection and plasmid-borne resistance.",
      },
    ],
    published: true,
    sort_order: 1,
    created_at: new Date().toISOString(),
  },
  {
    id: "kasus-2-kentang-osmosis",
    slug: "analisis-osmosis-jaringan-tumbuhan",
    bab_id: "sel",
    title_id: "Penalaran Osmosis: Menentukan Potensial Air Jaringan Tanaman",
    title_en: "Osmosis Reasoning: Determining Plant Tissue Water Potential",
    target_exam: "UTBK-SNBT",
    difficulty: "sedang",
    summary_id: "Analisis perubahan massa silinder umbi kentang pada variasi konsentrasi larutan sukrosa untuk menentukan konsentrasi isotonis sel.",
    summary_en: "Analysis of mass change in potato cylinders across sucrose concentrations to pinpoint cellular isotonicity.",
    scenario_id: "Sekelompok siswa melakukan penyelidikan transport zat melintasi membran sel. Lima silinder kentang dengan massa awal persis 5,00 gram direndam selama 60 menit ke dalam lima gelas beker berisi larutan sukrosa dengan konsentrasi berbeda-beda (0 M, 0,2 M, 0,4 M, 0,6 M, dan 0,8 M). Suhu ruangan dijaga stabil pada 25°C.",
    scenario_en: "Students investigated transmembrane solute transport. Five potato cylinders (initial mass 5.00 g) were submerged for 60 minutes in sucrose solutions (0 M to 0.8 M) at 25°C.",
    experiment_setup_id: "Setelah 60 menit perendaman, silinder kentang ditiriskan perlahan di atas kertas hisap selama 5 detik untuk membuang cairan permukaan, kemudian ditimbang kembali menggunakan timbangan digital analitik.",
    experiment_setup_en: "After 60 minutes, cylinders were blotted on filter paper for 5 seconds to remove surface moisture, then weighed on an analytical balance.",
    data_headers: ["Konsentrasi Sukrosa (M)", "Massa Awal (g)", "Massa Akhir (g)", "Perubahan Massa (%)", "Kondisi Tekstur Jaringan"],
    data_rows: [
      ["0,0 M (Aquades)", "5,00", "5,55", "+11,0%", "Sangat kaku dan turgid"],
      ["0,2 M", "5,00", "5,25", "+5,0%", "Kaku (turgid)"],
      ["0,3 M (Interpolasi)", "5,00", "5,00", "0,0%", "Normal (Isotonis)"],
      ["0,4 M", "5,00", "4,70", "-6,0%", "Sedikit lembek"],
      ["0,6 M", "5,00", "4,40", "-12,0%", "Sangat lembek (flaksid)"],
      ["0,8 M", "5,00", "4,15", "-17,0%", "Lembek & mengkerut (plasmolisis)"],
    ],
    variables: {
      independent: "Molaritas konsentrasi larutan sukrosa (0 M hingga 0,8 M)",
      dependent: "Persentase perubahan massa (%) dan kekakuan jaringan kentang",
      control: "Dimensi silinder kentang, volume larutan (50 mL), waktu perendaman (60 menit)",
    },
    questions: [
      {
        id: "q2",
        question_id: "Mengapa silinder kentang yang direndam dalam larutan sukrosa 0,8 M mengalami penurunan massa sebesar 17% dan teksturnya menjadi lembek?",
        question_en: "Why did potato cylinders soaked in 0.8 M sucrose lose 17% of their mass and turn flaccid?",
        options_id: [
          "Molekul sukrosa berukuran besar masuk menembus membran plasma dan memecah sel kentang",
          "Konsentrasi larutan luar bersifat hipertonis terhadap cairan sel kentang, sehingga molekul air keluar dari vakuola sel secara osmosis",
          "Sel kentang mengalami lisis karena air dari luar masuk terlalu deras melampaui kapasitas dinding sel",
          "Enzim intraseluler kentang mendegradasi amilum menjadi gas yang menguap ke udara",
          "Larutan sukrosa mengikis dinding sel selulosa sehingga silinder kentang mengecil",
        ],
        options_en: [
          "Large sucrose molecules penetrated the plasma membrane and ruptured potato cells",
          "The external solution was hypertonic to cell sap, causing water to exit cell vacuoles via osmosis",
          "Potato cells underwent lysis because external water entered excessively beyond cell wall capacity",
          "Intracellular enzymes degraded starch into vapor escaping into the air",
          "The sucrose solution dissolved the cellulose cell wall, shrinking the cylinder",
        ],
        correct_answer: 1,
        explanation_id: "Larutan sukrosa 0,8 M memiliki konsentrasi zat terlarut yang lebih pekat (hipertonis) dibanding cairan di dalam vakuola sel kentang. Akibatnya, molekul air bergerak dari potensial air tinggi (dalam sel) ke potensial air rendah (larutan luar). Kehilangan air menyebabkan tekanan turgor turun dan sel mengalami plasmolisis sehingga teksturnya menjadi lembek.",
        explanation_en: "The 0.8 M sucrose solution is hypertonic relative to potato cell sap. Water diffuses down its potential gradient outward, decreasing turgor pressure and triggering plasmolysis.",
        reasoning_steps_id: [
          "Langkah 1: Cek tanda minus pada perubahan massa (-17%), artinya massa berkurang karena zat cair keluar.",
          "Langkah 2: Ingat bahwa membran plasma tumbuhan semipermeabel; gula sukrosa tidak dapat bebas melintas, sehingga yang berpindah adalah molekul air.",
          "Langkah 3: Air selalu bergerak dari daerah hipotonis (encer) ke hipertonis (pekat). Karena luar pekat, air keluar dari sel.",
        ],
        reasoning_steps_en: [
          "Step 1: Note the negative mass change (-17%), indicating water loss.",
          "Step 2: Plant plasma membranes are semipermeable; water moves while sucrose cannot cross freely.",
          "Step 3: Water flows from hypotonic (inside) to hypertonic (outside) environments.",
        ],
        distractor_analysis_id: "Opsi A salah karena membran sel tidak permeable terhadap sukrosa tanpa transporter. Opsi C mendeskripsikan kondisi hipotonis (larutan 0 M). Opsi D dan E tidak berdasar secara fisiologi tumbuhan.",
        distractor_analysis_en: "Option A is false because sucrose cannot freely cross membranes. Option C describes hypotonic conditions (0 M). Options D and E are biologically incorrect.",
        utbk_tip_id: "Titik potong grafik perubahan massa pada angka 0% (pada kasus ini 0,3 M) adalah konsentrasi isotonis cairan sel tanaman tersebut.",
        utbk_tip_en: "The zero-intercept point (0% mass change, here ~0.3 M) represents the internal isotonic solute concentration of the tissue.",
      },
    ],
    published: true,
    sort_order: 2,
    created_at: new Date().toISOString(),
  },
];
