"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowLeft, Compass, CheckCircle2, XCircle, Sparkles, Lightbulb,
  Table, HelpCircle, ArrowRight, BookOpen, AlertCircle, RefreshCw,
} from "lucide-react";
import { useLangStore } from "@/lib/lang-store";
import type { BedahKasusItem } from "@/lib/bedah-kasus-data";

export default function BedahKasusDetailPage() {
  const params = useParams();
  const slug = params?.slug as string;
  const { lang } = useLangStore();

  const [item, setItem] = useState<BedahKasusItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  // Quiz Interaction State
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [submitted, setSubmitted] = useState<Record<string, boolean>>({});

  useEffect(() => {
    let alive = true;
    if (!slug) return;

    fetch(`/api/bedah-kasus?slug=${encodeURIComponent(slug)}`, { cache: "no-store" })
      .then((r) => r.json())
      .then((data) => {
        if (!alive) return;
        if (data.item) {
          setItem(data.item);
        } else {
          setNotFound(true);
        }
        setLoading(false);
      })
      .catch(() => {
        if (alive) {
          setNotFound(true);
          setLoading(false);
        }
      });

    return () => {
      alive = false;
    };
  }, [slug]);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 animate-pulse space-y-6">
        <div className="h-6 w-32 bg-border-light rounded-xl" />
        <div className="h-10 w-3/4 bg-border-light rounded-2xl" />
        <div className="h-48 bg-border-light rounded-3xl" />
        <div className="h-64 bg-border-light rounded-3xl" />
      </div>
    );
  }

  if (notFound || !item) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <Compass className="w-12 h-12 text-muted mx-auto mb-3 opacity-40" />
        <h2 className="text-xl font-extrabold text-ink mb-1">Studi Kasus Tidak Ditemukan</h2>
        <p className="text-xs text-muted mb-6">Mungkin tautan sudah berubah atau kasus telah dipindahkan.</p>
        <Link
          href="/bedah-kasus"
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-accent text-white text-xs font-bold rounded-xl"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali ke BioHOTS
        </Link>
      </div>
    );
  }

  const title = lang === "en" ? item.title_en || item.title_id : item.title_id;
  const scenario = lang === "en" ? item.scenario_en || item.scenario_id : item.scenario_id;
  const experiment = lang === "en" ? item.experiment_setup_en || item.experiment_setup_id : item.experiment_setup_id;

  const handleSelectOption = (qId: string, optIdx: number) => {
    if (submitted[qId]) return;
    setSelectedAnswers((prev) => ({ ...prev, [qId]: optIdx }));
  };

  const handleSubmitQuestion = (qId: string) => {
    if (selectedAnswers[qId] === undefined) return;
    setSubmitted((prev) => ({ ...prev, [qId]: true }));
  };

  const handleResetQuestion = (qId: string) => {
    setSelectedAnswers((prev) => {
      const copy = { ...prev };
      delete copy[qId];
      return copy;
    });
    setSubmitted((prev) => {
      const copy = { ...prev };
      delete copy[qId];
      return copy;
    });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 sm:py-8 animate-fade-in-up">
      {/* Back link */}
      <Link
        href="/bedah-kasus"
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted hover:text-accent mb-4 transition-colors"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        Kembali ke BioHOTS
      </Link>

      {/* Case Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2 flex-wrap">
          <span className="text-[10px] font-extrabold uppercase px-2.5 py-0.5 rounded-full bg-accent/10 text-accent">
            {item.target_exam}
          </span>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-bg-alt text-muted border border-border-light capitalize">
            Bab {item.bab_id}
          </span>
          <span className="text-[10px] font-semibold text-muted capitalize">
            Tingkat {item.difficulty.replace("_", " ")}
          </span>
        </div>

        <h1 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-ink leading-tight mb-2">
          {title}
        </h1>
        <p className="text-xs sm:text-sm text-muted leading-relaxed">
          {item.summary_id}
        </p>
      </div>

      {/* ── BAGIAN 1: SKENARIO & METODOLOGI ── */}
      <div className="rounded-3xl bg-surface border border-border/70 p-5 sm:p-7 shadow-card mb-6">
        <div className="flex items-center gap-2.5 mb-3 text-ink">
          <div className="w-8 h-8 rounded-xl bg-accent/10 text-accent flex items-center justify-center font-bold text-sm">
            1
          </div>
          <h2 className="text-base sm:text-lg font-extrabold">
            Skenario Masalah & Desain Penelitian
          </h2>
        </div>

        <p className="text-xs sm:text-[13.5px] text-ink/90 leading-relaxed bg-bg-alt/60 p-4 rounded-2xl border border-border/40 mb-4">
          {scenario}
        </p>

        {experiment && (
          <div className="mb-4">
            <h4 className="text-xs font-bold text-ink mb-1 flex items-center gap-1.5">
              <span>🔬</span>
              <span>Prosedur Pengujian:</span>
            </h4>
            <p className="text-xs text-muted leading-relaxed">
              {experiment}
            </p>
          </div>
        )}

        {/* Variabel Penelitian */}
        {item.variables && (item.variables.independent || item.variables.dependent) && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-3 border-t border-border/50 text-xs">
            <div className="p-3 rounded-xl bg-accent/[0.04] border border-accent/15">
              <span className="text-[10px] font-bold uppercase tracking-wider text-accent block mb-0.5">
                Variabel Bebas (Manipulasi)
              </span>
              <p className="font-semibold text-ink text-xs">{item.variables.independent || "-"}</p>
            </div>
            <div className="p-3 rounded-xl bg-cyan-500/[0.04] border border-cyan-500/20">
              <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-800 dark:text-cyan-300 block mb-0.5">
                Variabel Terikat (Respon)
              </span>
              <p className="font-semibold text-ink text-xs">{item.variables.dependent || "-"}</p>
            </div>
            <div className="p-3 rounded-xl bg-bg-alt border border-border/60">
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted block mb-0.5">
                Variabel Kontrol (Tetap)
              </span>
              <p className="font-semibold text-ink text-xs">{item.variables.control || "-"}</p>
            </div>
          </div>
        )}
      </div>

      {/* ── BAGIAN 2: BUKTI & TABEL DATA EKSPERIMEN ── */}
      {item.data_headers && item.data_headers.length > 0 && item.data_rows && item.data_rows.length > 0 && (
        <div className="rounded-3xl bg-surface border border-border/70 p-5 sm:p-7 shadow-card mb-6">
          <div className="flex items-center gap-2.5 mb-3 text-ink">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/10 text-cyan-700 dark:text-cyan-400 flex items-center justify-center font-bold text-sm">
              2
            </div>
            <h2 className="text-base sm:text-lg font-extrabold">
              Bukti Percobaan (Tabel Data Hasil Uji)
            </h2>
          </div>

          <p className="text-xs text-muted mb-4 leading-relaxed">
            Perhatikan pola data, tren perbandingan, atau anomali angka pada tabel di bawah untuk menarik kesimpulan yang valid:
          </p>

          <div className="overflow-x-auto rounded-2xl border border-border/60">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-bg-alt border-b border-border text-ink font-bold">
                  {item.data_headers.map((h, i) => (
                    <th key={i} className="p-3 whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border/40">
                {item.data_rows.map((row, rIdx) => (
                  <tr key={rIdx} className="hover:bg-bg-alt/40 transition-colors">
                    {row.map((cell, cIdx) => (
                      <td key={cIdx} className={`p-3 text-ink ${cIdx === 0 ? "font-bold text-accent" : ""}`}>
                        {cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── BAGIAN 3: SOAL & UJI PENALARAN ── */}
      <div className="space-y-6">
        {item.questions.map((q, qIdx) => {
          const qId = q.id || `q_${qIdx}`;
          const isDone = submitted[qId];
          const userChoice = selectedAnswers[qId];
          const isCorrect = userChoice === q.correct_answer;
          const options = lang === "en" ? q.options_en || q.options_id : q.options_id;

          return (
            <div key={qId} className="rounded-3xl bg-surface border border-border/80 p-5 sm:p-7 shadow-card overflow-hidden">
              <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-700 dark:text-purple-300 flex items-center justify-center font-bold text-sm">
                    {qIdx + 3}
                  </div>
                  <span className="text-xs font-extrabold uppercase tracking-wider text-accent">
                    Tantangan Penalaran Sains #{qIdx + 1}
                  </span>
                </div>
                {isDone && (
                  <span className={`inline-flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full ${
                    isCorrect ? "bg-green/10 text-green" : "bg-red/10 text-red"
                  }`}>
                    {isCorrect ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                    {isCorrect ? "Penalaran Tepat!" : "Belum Tepat"}
                  </span>
                )}
              </div>

              <h3 className="font-extrabold text-sm sm:text-base text-ink mb-4 leading-relaxed">
                {lang === "en" ? q.question_en || q.question_id : q.question_id}
              </h3>

              {/* Options */}
              <div className="space-y-2.5 mb-5">
                {options.map((opt, optIdx) => {
                  const isSelected = userChoice === optIdx;
                  const isAnswerKey = optIdx === q.correct_answer;

                  let optCls = "border-border/70 hover:border-accent/40 bg-surface text-ink";
                  if (isSelected && !isDone) {
                    optCls = "border-accent bg-accent/5 text-ink ring-1 ring-accent";
                  }
                  if (isDone) {
                    if (isAnswerKey) {
                      optCls = "border-green bg-green/10 text-green font-semibold";
                    } else if (isSelected && !isCorrect) {
                      optCls = "border-red bg-red/10 text-red";
                    } else {
                      optCls = "border-border/40 opacity-50 text-muted";
                    }
                  }

                  return (
                    <button
                      key={optIdx}
                      type="button"
                      disabled={isDone}
                      onClick={() => handleSelectOption(qId, optIdx)}
                      className={`w-full text-left p-3.5 sm:p-4 rounded-2xl border transition-all flex items-start gap-3 cursor-pointer ${optCls}`}
                    >
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                        isSelected && !isDone
                          ? "bg-accent text-white"
                          : isDone && isAnswerKey
                          ? "bg-green text-white"
                          : isDone && isSelected && !isCorrect
                          ? "bg-red text-white"
                          : "bg-bg-alt text-muted"
                      }`}>
                        {["A", "B", "C", "D", "E"][optIdx]}
                      </span>
                      <span className="text-xs sm:text-sm leading-relaxed flex-1">
                        {opt}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Submit action */}
              {!isDone ? (
                <div className="flex items-center justify-end">
                  <button
                    type="button"
                    disabled={userChoice === undefined}
                    onClick={() => handleSubmitQuestion(qId)}
                    className="px-5 py-2.5 rounded-xl bg-accent text-white text-xs font-bold hover:bg-accent-dark transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-xs"
                  >
                    Periksa Penalaran →
                  </button>
                </div>
              ) : (
                /* ── BAGIAN 4: BEDAH LOGIKA & TRIK UTBK ── */
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4 }}
                  className="space-y-4 pt-4 border-t border-border/70"
                >
                  {/* Penjelasan Inti */}
                  <div className="p-4 rounded-2xl bg-bg-alt/70 border border-border/60">
                    <h4 className="text-xs font-extrabold text-ink mb-1.5 flex items-center gap-1.5">
                      <span>💡</span>
                      <span>Konsep Sains Utama:</span>
                    </h4>
                    <p className="text-xs sm:text-[13px] text-ink/80 leading-relaxed">
                      {lang === "en" ? q.explanation_en || q.explanation_id : q.explanation_id}
                    </p>
                  </div>

                  {/* Langkah Penalaran Bertahap */}
                  {q.reasoning_steps_id && q.reasoning_steps_id.length > 0 && (
                    <div className="p-4 rounded-2xl bg-accent/[0.04] border border-accent/15">
                      <h4 className="text-xs font-extrabold text-accent mb-2 flex items-center gap-1.5">
                        <span>🔍</span>
                        <span>Langkah Logika Penarikan Simpulan:</span>
                      </h4>
                      <ol className="space-y-1.5 text-xs text-ink/85 leading-relaxed list-decimal list-inside">
                        {q.reasoning_steps_id.map((step, sIdx) => (
                          <li key={sIdx} className="pl-1">{step}</li>
                        ))}
                      </ol>
                    </div>
                  )}

                  {/* Bedah Pilihan Pengecoh */}
                  {q.distractor_analysis_id && (
                    <div className="p-4 rounded-2xl bg-surface border border-border/60 text-xs">
                      <span className="font-extrabold text-muted-2 uppercase tracking-wider text-[10px] block mb-1">
                        Kenapa Opsi Lain Kurang Tepat?
                      </span>
                      <p className="text-muted leading-relaxed">
                        {q.distractor_analysis_id}
                      </p>
                    </div>
                  )}

                  {/* Trik Cepat UTBK */}
                  {q.utbk_tip_id && (
                    <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-orange-500/5 to-surface border border-amber-500/25">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-800 dark:text-amber-300 flex items-center gap-1 mb-1">
                        <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                        Trik Cepat Khas UTBK:
                      </span>
                      <p className="text-xs font-semibold text-ink leading-relaxed">
                        {q.utbk_tip_id}
                      </p>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-2">
                    <button
                      type="button"
                      onClick={() => handleResetQuestion(qId)}
                      className="inline-flex items-center gap-1 text-xs text-muted hover:text-ink font-semibold"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Coba Ulang Soal Ini
                    </button>
                    <Link
                      href="/bedah-kasus"
                      className="inline-flex items-center gap-1 text-xs font-bold text-accent hover:underline"
                    >
                      Studi Kasus Lainnya
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                </motion.div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
