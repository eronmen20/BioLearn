import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/lib/db";
import { requireAdmin } from "@/lib/admin-guard";
import { logActivity } from "@/lib/activity-log";
import { INITIAL_BEDAH_KASUS, type BedahKasusItem } from "@/lib/bedah-kasus-data";

export const dynamic = "force-dynamic";

async function loadAllCases(): Promise<BedahKasusItem[]> {
  const supabase = getDb();
  const { data } = await supabase
    .from("site_settings")
    .select("value")
    .eq("key", "bedah_kasus")
    .single();

  if (data?.value && Array.isArray(data.value) && data.value.length > 0) {
    return data.value;
  }
  return [...INITIAL_BEDAH_KASUS];
}

async function saveAllCases(cases: BedahKasusItem[], req: NextRequest, actionDetail: string) {
  const supabase = getDb();
  const { error } = await supabase
    .from("site_settings")
    .upsert({
      key: "bedah_kasus",
      value: cases,
      updated_at: new Date().toISOString(),
    }, { onConflict: "key" });

  if (error) throw error;

  const adminEmail = req.headers.get("x-admin-email") || "admin";
  const ip = req.headers.get("x-forwarded-for") || "unknown";
  await logActivity({
    user_email: adminEmail,
    action: "update",
    target_type: "bedah_kasus",
    target_id: "site_settings.bedah_kasus",
    detail: { message: actionDetail, totalCases: cases.length },
    ip_address: ip,
  });
}

// GET - List all cases
export async function GET(req: NextRequest) {
  try {
    const auth = await requireAdmin(req);
    if (auth instanceof NextResponse) return auth;

    const cases = await loadAllCases();
    return NextResponse.json({ cases });
  } catch (e) {
    console.error("[API Admin Bedah Kasus GET]", e);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

// POST - Create new case or batch replace
export async function POST(req: NextRequest) {
  try {
    const auth = await requireAdmin(req);
    if (auth instanceof NextResponse) return auth;

    const body = await req.json();
    const cases = await loadAllCases();

    if (body.action === "reset_defaults") {
      await saveAllCases(INITIAL_BEDAH_KASUS, req, "Reset to default UTBK cases");
      return NextResponse.json({ success: true, cases: INITIAL_BEDAH_KASUS });
    }

    if (!body.title_id?.trim()) {
      return NextResponse.json({ error: "Judul kasus wajib diisi" }, { status: 400 });
    }

    const newId = body.id || `kasus-${Date.now()}`;
    const newSlug = body.slug || newId;

    const newCase: BedahKasusItem = {
      id: newId,
      slug: newSlug,
      bab_id: body.bab_id || "bakteri",
      title_id: body.title_id,
      title_en: body.title_en || "",
      target_exam: body.target_exam || "UTBK-SNBT",
      difficulty: body.difficulty || "sedang",
      summary_id: body.summary_id || "",
      summary_en: body.summary_en || "",
      scenario_id: body.scenario_id || "",
      scenario_en: body.scenario_en || "",
      experiment_setup_id: body.experiment_setup_id || "",
      experiment_setup_en: body.experiment_setup_en || "",
      image_url: body.image_url || "",
      image_caption_id: body.image_caption_id || "",
      image_caption_en: body.image_caption_en || "",
      data_headers: Array.isArray(body.data_headers) ? body.data_headers : [],
      data_rows: Array.isArray(body.data_rows) ? body.data_rows : [],
      variables: body.variables || { independent: "", dependent: "", control: "" },
      questions: Array.isArray(body.questions) ? body.questions : [],
      published: body.published ?? true,
      sort_order: body.sort_order ?? (cases.length + 1),
      created_at: new Date().toISOString(),
    };

    cases.push(newCase);
    await saveAllCases(cases, req, `Created case: ${newCase.title_id}`);

    return NextResponse.json({ success: true, item: newCase });
  } catch (e) {
    console.error("[API Admin Bedah Kasus POST]", e);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

// PUT - Update an existing case
export async function PUT(req: NextRequest) {
  try {
    const auth = await requireAdmin(req);
    if (auth instanceof NextResponse) return auth;

    const body = await req.json();
    if (!body.id) {
      return NextResponse.json({ error: "ID kasus wajib disertakan" }, { status: 400 });
    }

    const cases = await loadAllCases();
    const idx = cases.findIndex((c) => c.id === body.id);
    if (idx === -1) {
      return NextResponse.json({ error: "Kasus tidak ditemukan" }, { status: 404 });
    }

    cases[idx] = {
      ...cases[idx],
      ...body,
      updated_at: new Date().toISOString(),
    };

    await saveAllCases(cases, req, `Updated case: ${cases[idx].title_id}`);
    return NextResponse.json({ success: true, item: cases[idx] });
  } catch (e) {
    console.error("[API Admin Bedah Kasus PUT]", e);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

// DELETE - Delete a case
export async function DELETE(req: NextRequest) {
  try {
    const auth = await requireAdmin(req);
    if (auth instanceof NextResponse) return auth;

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ error: "ID kasus wajib disertakan" }, { status: 400 });
    }

    let cases = await loadAllCases();
    const target = cases.find((c) => c.id === id);
    cases = cases.filter((c) => c.id !== id);

    await saveAllCases(cases, req, `Deleted case: ${target?.title_id || id}`);
    return NextResponse.json({ success: true });
  } catch (e) {
    console.error("[API Admin Bedah Kasus DELETE]", e);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
