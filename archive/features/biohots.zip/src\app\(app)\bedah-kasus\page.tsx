"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "motion/react";
import {
  Compass, ArrowRight, Sparkles, Filter, Search, BookOpen, Layers,
  CheckCircle2, AlertTriangle, ArrowLeft,
} from "lucide-react";
import { useLangStore } from "@/lib/lang-store";
import type { BedahKasusItem } from "@/lib/bedah-kasus-data";

export default function BedahKasusCatalogPage() {
  const { lang } = useLangStore();
  const [items, setItems] = useState<BedahKasusItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [examFilter, setExamFilter] = useState<string>("all");
  const [babFilter, setBabFilter] = useState<string>("all");
  const [search, setSearch] = useState("");

  useEffect(() => {
    let alive = true;
    fetch(`/api/bedah-kasus`, { cache: "no-store" })
      .then((r) => r.json())
      .then((data) => {
        if (alive) {
          setItems(data.items || []);
          setLoading(false);
        }
      })
      .catch(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, []);

  const filtered = items.filter((item) => {
    if (examFilter !== "all" && item.target_exam !== examFilter) return false;
    if (babFilter !== "all" && item.bab_id !== babFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      const title = (item.title_id || "").toLowerCase();
      const summary = (item.summary_id || "").toLowerCase();
      if (!title.includes(q) && !summary.includes(q)) return false;
    }
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 animate-fade-in-up">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-ink mb-2">
          BioHOTS
        </h1>
        <p className="text-xs sm:text-sm text-muted leading-relaxed max-w-2xl">
          {lang === "en"
            ? "Master higher-order thinking skills through authentic biology scenarios, experimental tables, and step-by-step logic breakdowns."
            : "Latih kemampuan literasi sains HOTS lewat analisis tabel data percobaan, skenario laboratorium riil, dan bedah logika penarikan kesimpulan."}
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-6 p-3 rounded-2xl bg-surface border border-border/70 shadow-xs">
        <div className="flex items-center gap-2 flex-wrap">
          {/* Exam Filter */}
          <div className="flex items-center gap-1 bg-bg-alt p-1 rounded-xl border border-border/50 text-xs font-semibold">
            {[
              { id: "all", label: "Semua Ujian" },
              { id: "UTBK-SNBT", label: "UTBK-SNBT" },
              { id: "TKA Saintek", label: "TKA Saintek" },
            ].map((btn) => (
              <button
                key={btn.id}
                onClick={() => setExamFilter(btn.id)}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  examFilter === btn.id
                    ? "bg-surface text-ink font-bold shadow-xs"
                    : "text-muted hover:text-ink"
                }`}
              >
                {btn.label}
              </button>
            ))}
          </div>

          {/* Bab Filter */}
          <select
            value={babFilter}
            onChange={(e) => setBabFilter(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-border/60 bg-bg-alt text-xs font-semibold text-ink focus:outline-none"
          >
            <option value="all">Semua Bab</option>
            <option value="bakteri">Bab Bakteri</option>
            <option value="sel">Bab Sel</option>
            <option value="virus">Bab Virus</option>
          </select>
        </div>

        {/* Search Input */}
        <div className="relative min-w-[200px]">
          <Search className="w-3.5 h-3.5 text-muted absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari kasus sains..."
            className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-border/60 bg-bg-alt text-xs text-ink placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-accent/30"
          />
        </div>
      </div>

      {/* Content List */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2].map((n) => (
            <div key={n} className="h-44 rounded-3xl bg-surface border border-border/50 animate-pulse p-6" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 bg-surface rounded-3xl border border-dashed border-border p-8">
          <Compass className="w-10 h-10 text-muted mx-auto mb-2 opacity-50" />
          <p className="text-sm font-bold text-ink">Tidak ada studi kasus yang cocok</p>
          <p className="text-xs text-muted mt-1">Coba sesuaikan filter pencarian atau pilih kategori ujian lain.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((item, idx) => {
            const title = lang === "en" ? item.title_en || item.title_id : item.title_id;
            const summary = lang === "en" ? item.summary_en || item.summary_id : item.summary_id;
            return (
              <Link key={item.id || idx} href={`/bedah-kasus/${item.slug}`} className="group">
                <div className="relative p-5 sm:p-6 rounded-3xl bg-surface border border-border/70 shadow-card hover:border-accent/40 hover:-translate-y-1 transition-all h-full flex flex-col justify-between overflow-hidden">
                  <div className="h-1.5 w-full bg-gradient-to-r from-accent via-purple-500 to-cyan-400 absolute top-0 left-0 right-0" />

                  <div>
                    <div className="flex items-center gap-2 mb-2.5 flex-wrap">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-accent/10 text-accent">
                        {item.target_exam}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-bg-alt text-muted border border-border-light capitalize">
                        {item.bab_id}
                      </span>
                      <span className="text-[10px] font-semibold text-muted ml-auto capitalize">
                        {item.difficulty.replace("_", " ")}
                      </span>
                    </div>

                    <h3 className="font-extrabold text-base sm:text-lg text-ink mb-1.5 leading-snug group-hover:text-accent transition-colors">
                      {title}
                    </h3>
                    <p className="text-xs sm:text-sm text-muted leading-relaxed line-clamp-2 mb-4">
                      {summary}
                    </p>
                  </div>

                  <div>
                    <div className="flex items-center gap-3 text-[11px] text-muted-2 pt-3 border-t border-border/50 mb-3">
                      <span>📊 Data Eksperimen</span>
                      <span>•</span>
                      <span>🧩 {item.questions?.length || 1} Soal Penalaran</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-accent group-hover:underline flex items-center gap-1">
                        Buka BioHOTS
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
