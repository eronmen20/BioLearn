# Archive: Fitur BioHOTS (Bedah Soal UTBK/TKA)

Fitur ini diarsipkan sementara sampai seluruh materi biologi dasar selesai disusun.

## Isi Fitur yang Diarsipkan
1. **Katalog Siswa**: `src/app/(app)/bedah-kasus/page.tsx`
2. **Arena Penalaran Siswa**: `src/app/(app)/bedah-kasus/[slug]/page.tsx`
3. **Admin Panel**: `src/app/admin/content/bedah-kasus/page.tsx`
4. **API Publik**: `src/app/api/bedah-kasus/route.ts`
5. **API Admin**: `src/app/api/admin/bedah-kasus/route.ts`
6. **Data Bawaan (Seed Data)**: `src/lib/bedah-kasus-data.ts`
7. **Integrasi UI**: `archive/features/biohots/ui_integrations.patch` (Sidebar siswa, sidebar admin, dashboard card, i18n)

---

## Cara Mengaktifkan Kembali (Restore)

Cukup jalankan script restore di PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\archive\features\biohots\restore.ps1
```

Atau salin manual folder `src` dari direktori arsip ini ke root proyek, lalu terapkan patch UI.
